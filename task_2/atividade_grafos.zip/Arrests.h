/*
 * Trabalho 1 - Zoologico
 *
 * GEN254 - Grafos - 2025/1
 *
 * Nome:      Pedro Henrique Klein
 * Matricula: 2111100060
 */

#ifndef ARRESTS_H
#define ARRESTS_H
#include <vector> 

class Arrests {
    public:
        Arrests(int v1_, int v2);
        const int v1_;
        const int v2_;
};

#endif