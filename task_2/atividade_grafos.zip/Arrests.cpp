/*
 * Trabalho 1 - Zoologico
 *
 * GEN254 - Grafos - 2025/1
 *
 * Nome:      Pedro Henrique Klein
 * Matricula: 2111100060
 */

#include <iostream>
#include "Arrests.h"

using namespace std;

Arrests::Arrests(int v1, int v2) :  v1_(v1), v2_(v2) {}
